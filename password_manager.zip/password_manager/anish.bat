@echo off
"C:\Users\anish\AppData\Local\Programs\Python\Python314\python.exe" "E:\cyber-projects\password_manager\main.py"