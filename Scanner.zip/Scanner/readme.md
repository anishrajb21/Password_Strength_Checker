# 🛡️ Cybersecurity Vulnerability Scanner Dashboard

A full-stack cybersecurity dashboard that scans targets, analyzes vulnerabilities, and generates professional reports with visual insights.

---

## 🚀 Features

- 🔐 User Authentication (Login & Register)
- 🌐 Multi-target scanning (IP / Domain)
- 🛠️ Port scanning & service detection
- 📊 Risk classification (SAFE / LOW / MEDIUM / HIGH)
- 🧠 CVSS scoring for vulnerabilities
- 📈 Risk visualization using charts
- 🗂️ Scan history (stored per user)
- 🔍 View previous scan reports
- 📄 Export reports as:
  - CSV
  - PDF (includes chart + summary + table)
- 💻 Terminal-style scan simulation UI

---

## 🧰 Tech Stack

### Backend
- Python (Flask)
- SQLite (Database)

### Frontend
- HTML
- CSS (Cybersecurity-themed UI)
- Chart.js

### Libraries
- ReportLab (PDF generation)
- Matplotlib (chart rendering)

---

## 📂 Project Structure

CYBER-PROJECTS/
│
├── static/
│ └── style.css
│
├── templates/
│ ├── index.html
│ ├── login.html
│ └── register.html
│
├── app.py
├── auth.py
├── scanner.py
├── analyzer.py
├── database.db
├── requirements.txt
└── README.md

# Install dependencies
pip install -r requirements.txt

# Install dependencies
pip install -r requirements.txt

# Run application
python app.py

# open in browser
http://127.0.0.1:5000