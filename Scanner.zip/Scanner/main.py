from rich.progress import track
from scanner import scan_target
from analyzer import analyze
from rich.console import Console
from rich.table import Table
import json
import os
import datetime

console = Console()

# Take multiple targets
targets = input("Enter targets (comma separated): ").split(",")

all_reports = []

for target in track(targets, description="Scanning targets..."):
    target = target.strip()

    print(f"\n[+] Scanning {target}...")
    scan_results = scan_target(target)

    print("[+] Analyzing vulnerabilities...")
    report = analyze(scan_results, target)

    all_reports.append({
        "target": target,
        "report": report
    })

    # Create table for each target
    table = Table(title=f"Vulnerability Report for {target}")

    table.add_column("Port", style="cyan")
    table.add_column("Service", style="green")
    table.add_column("Version", style="yellow")
    table.add_column("Risk", style="red")
    table.add_column("Warning", style="magenta")

    for r in track(report, description=f"Processing {target}..."):
        table.add_row(
            str(r["port"]),
            r["service"],
            r["version"],
            r["status"],
            r["warning"]
        )

    console.print(table)

# ✅ NEW: Add timestamp + append logic
file_name = "report.json"

scan_entry = {
    "timestamp": str(datetime.datetime.now()),
    "data": all_reports
}

# Load old data if exists
if os.path.exists(file_name):
    with open(file_name, "r") as f:
        try:
            existing_data = json.load(f)
        except:
            existing_data = []
else:
    existing_data = []

# Append new scan
existing_data.append(scan_entry)

# Save updated data
with open(file_name, "w") as f:
    json.dump(existing_data, f, indent=4)

print("\n[+] Report appended with timestamp to report.json")