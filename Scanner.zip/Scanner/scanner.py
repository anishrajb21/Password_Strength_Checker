import nmap

def scan_target(target):
    nm = nmap.PortScanner()
    nm.scan(target, arguments='-sV')  # service detection

    results = []

    for host in nm.all_hosts():
        for proto in nm[host].all_protocols():
            ports = nm[host][proto].keys()
            for port in ports:
                service = nm[host][proto][port]
                
                results.append({
                    "port": port,
                    "state": service['state'],
                    "name": service['name'],
                    "product": service.get('product', ''),
                    "version": service.get('version', '')
                })

    return results