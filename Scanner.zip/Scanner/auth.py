import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

DB = "database.db"

def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    # users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        password TEXT
    )
    """)

    # 🔥 ADD THIS (IMPORTANT)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        target TEXT,
        result TEXT,
        timestamp TEXT
    )
    """)

    conn.commit()
    conn.close()

def register_user(username, password):
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()

    hashed = generate_password_hash(password)

    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed))
        conn.commit()
        return True
    except:
        return False
    finally:
        conn.close()

def login_user(username, password):
    conn = sqlite3.connect(DB)
    cursor = conn.cursor()

    cursor.execute("SELECT id, password FROM users WHERE username=?", (username,))
    user = cursor.fetchone()

    conn.close()

    if user and check_password_hash(user[1], password):
        return user[0]  # return user_id

    return None