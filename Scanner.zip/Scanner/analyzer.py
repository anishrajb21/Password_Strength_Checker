from cve_lookup import check_vulnerability
from banner import grab_banner

def get_cvss(service, port):
    service = service.lower()

    if service in ["ftp", "telnet"]:
        return " HIGH"
    elif service in ["http"]:
        return " MEDIUM"
    elif service in ["ssh"]:
        return "LOW"
    elif port in [445, 139]:
        return " MEDIUM"
    else:
        return "LOW"

def basic_checks(service, port):
    if service == "ftp":
        return "FTP is insecure"
    if port == 23:
        return " Telnet is insecure"
    if port == 80:
        return " HTTP (no encryption)"
    return "OK"


def analyze(scan_results, target):
    report = []

    for item in scan_results:
        if item["state"] == "open":
            vuln_status = check_vulnerability(item["name"], item["version"])
            warning = basic_checks(item["name"], item["port"])
            banner = grab_banner(target, item["port"])

            cvss = get_cvss(item["name"], item["port"])

            report.append({
                "port": item["port"],
                "service": item["name"],
                "version": item["version"],
                "status": vuln_status,
                "banner": banner,
                "warning": warning,
                "cvss": cvss   # ✅ ADD THIS
            })

    return report