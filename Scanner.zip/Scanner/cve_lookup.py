import requests

def check_vulnerability(service, version):
    query = f"{service} {version}"
    url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={query}"

    try:
        response = requests.get(url)
        data = response.json()

        total = data.get("totalResults", 0)

        if total > 50:
            return "HIGH RISK"
        elif total > 10:
            return "MEDIUM RISK"
        elif total > 0:
            return "LOW RISK"
        else:
            return "SAFE"
    except:
        return "Error"