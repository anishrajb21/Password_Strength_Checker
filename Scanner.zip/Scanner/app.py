import csv
import sqlite3
import json
from datetime import datetime
from flask import Flask, render_template, request, Response, session, redirect

from auth import init_db, register_user, login_user
from scanner import scan_target
from analyzer import analyze

# PDF
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO

# CHART
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = "supersecretkey"

# INIT DB
init_db()

# GLOBALS
last_report = []
last_target = ""


# -----------------------------
# DATABASE FUNCTIONS
# -----------------------------
def save_scan(user_id, target, report):
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        target TEXT,
        result TEXT,
        timestamp TEXT
    )
    """)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute(
        "INSERT INTO scans (user_id, target, result, timestamp) VALUES (?, ?, ?, ?)",
        (user_id, target, json.dumps(report), timestamp)
    )

    conn.commit()
    conn.close()


def get_history(user_id):
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("SELECT id, target, timestamp FROM scans WHERE user_id=?", (user_id,))
    data = cursor.fetchall()

    conn.close()
    return data


# -----------------------------
# AUTH ROUTES
# -----------------------------
@app.route("/")
def home():
    if "user_id" not in session:
        return redirect("/login")

    history = get_history(session["user_id"])

    return render_template(
        "index.html",
        history=history,
        all_reports=[]
    )


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        if register_user(request.form["username"], request.form["password"]):
            return redirect("/login")
        return render_template("register.html", error="User already exists")

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_id = login_user(request.form["username"], request.form["password"])

        if user_id:
            session["user_id"] = user_id
            return redirect("/")
        return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


# -----------------------------
# SCAN ROUTE
# -----------------------------
@app.route("/scan", methods=["POST"])
def scan():
    if "user_id" not in session:
        return redirect("/login")

    global last_report, last_target

    user_id = session["user_id"]
    targets = request.form.get("target").split(",")

    all_reports = []

    for t in targets:
        t = t.strip()

        scan_results = scan_target(t)
        report = analyze(scan_results, t)

        save_scan(user_id, t, report)

        # RISK COUNT
        risk_counts = {"SAFE": 0, "LOW": 0, "MEDIUM": 0, "HIGH": 0}

        for r in report:
            if "HIGH" in r["status"]:
                risk_counts["HIGH"] += 1
            elif "MEDIUM" in r["status"]:
                risk_counts["MEDIUM"] += 1
            elif "LOW" in r["status"]:
                risk_counts["LOW"] += 1
            else:
                risk_counts["SAFE"] += 1

        all_reports.append({
            "target": t,
            "report": report,
            "risk_counts": risk_counts
        })

    # SAVE LAST SCAN
    if all_reports:
        last_report = all_reports[-1]["report"]
        last_target = all_reports[-1]["target"]

    history = get_history(user_id)

    return render_template(
        "index.html",
        all_reports=all_reports,
        history=history
    )


# -----------------------------
# VIEW OLD SCAN
# -----------------------------
@app.route("/view_scan/<int:scan_id>")
def view_scan(scan_id):
    if "user_id" not in session:
        return redirect("/login")

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("SELECT target, result FROM scans WHERE id=?", (scan_id,))
    data = cursor.fetchone()
    conn.close()

    if not data:
        return "Scan not found"

    target = data[0]
    report = json.loads(data[1])

    risk_counts = {"SAFE": 0, "LOW": 0, "MEDIUM": 0, "HIGH": 0}

    for r in report:
        if "HIGH" in r["status"]:
            risk_counts["HIGH"] += 1
        elif "MEDIUM" in r["status"]:
            risk_counts["MEDIUM"] += 1
        elif "LOW" in r["status"]:
            risk_counts["LOW"] += 1
        else:
            risk_counts["SAFE"] += 1

    history = get_history(session["user_id"])

    return render_template(
        "index.html",
        all_reports=[{
            "target": target,
            "report": report,
            "risk_counts": risk_counts
        }],
        history=history
    )


# -----------------------------
# DOWNLOAD CSV
# -----------------------------
@app.route("/download")
def download():
    if "user_id" not in session:
        return redirect("/login")

    def generate():
        yield "Port,Service,Version,Risk,Warning\n"
        for r in last_report:
            yield f"{r['port']},{r['service']},{r['version']},{r['status']},{r['warning']}\n"

    return Response(
        generate(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=report.csv"}
    )


# -----------------------------
# DOWNLOAD PDF (FINAL FIXED)
# -----------------------------
@app.route("/download_pdf")
def download_pdf():
    if "user_id" not in session:
        return redirect("/login")

    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)

    elements = []
    styles = getSampleStyleSheet()

    # TITLE
    elements.append(Paragraph("Vulnerability Scan Report", styles['Title']))
    elements.append(Paragraph(f"Target: {last_target}", styles['Normal']))
    elements.append(Paragraph(" ", styles['Normal']))

    # RISK COUNT
    risk_counts = {"SAFE": 0, "LOW": 0, "MEDIUM": 0, "HIGH": 0}

    for r in last_report:
        if "HIGH" in r["status"]:
            risk_counts["HIGH"] += 1
        elif "MEDIUM" in r["status"]:
            risk_counts["MEDIUM"] += 1
        elif "LOW" in r["status"]:
            risk_counts["LOW"] += 1
        else:
            risk_counts["SAFE"] += 1

    # SUMMARY
    elements.append(Paragraph("Summary", styles['Heading2']))
    elements.append(Paragraph(
        f"SAFE: {risk_counts['SAFE']} | LOW: {risk_counts['LOW']} | "
        f"MEDIUM: {risk_counts['MEDIUM']} | HIGH: {risk_counts['HIGH']}",
        styles['Normal']
    ))

    elements.append(Paragraph(" ", styles['Normal']))

    # CHART (IN MEMORY)
    labels = ["SAFE", "LOW", "MEDIUM", "HIGH"]
    values = list(risk_counts.values())
    colors_chart = ["#00ff41", "#ffcc00", "#ff8800", "#ff0033"]

    img_buffer = BytesIO()

    plt.figure(figsize=(4, 4))
    plt.pie(values, labels=labels, colors=colors_chart, autopct='%1.0f%%')
    plt.title("Risk Distribution")

    plt.savefig(img_buffer, format='png')
    plt.close()

    img_buffer.seek(0)

    elements.append(Paragraph("Risk Distribution", styles['Heading2']))
    elements.append(Image(img_buffer, width=250, height=250))

    elements.append(Paragraph(" ", styles['Normal']))

    # TABLE
    data = [["Port", "Service", "Version", "Risk", "Warning", "CVSS"]]

    for r in last_report:
        data.append([
            str(r["port"]),
            r["service"],
            r["version"],
            r["status"],
            r["warning"],
            r["cvss"]
        ])

    table = Table(data)
    table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
    ]))

    elements.append(Paragraph("Detailed Report", styles['Heading2']))
    elements.append(table)

    doc.build(elements)

    buffer.seek(0)

    return Response(
        buffer,
        mimetype="application/pdf",
        headers={"Content-Disposition": "attachment;filename=report.pdf"}
    )


# -----------------------------
# RUN
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)

    