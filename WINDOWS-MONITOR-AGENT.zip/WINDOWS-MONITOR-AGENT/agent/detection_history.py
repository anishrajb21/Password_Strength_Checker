"""
agent/detection_history.py

Stores malware detections and prevents duplicates.
"""

from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime


class DetectionHistory:

    def __init__(self):

        self.file = Path("database/detection_history.json")

        if not self.file.exists():

            with open(self.file, "w", encoding="utf-8") as f:
                json.dump([], f, indent=4)

    def load(self):

        with open(self.file, "r", encoding="utf-8") as f:

            return json.load(f)

    def save(self, history):

        with open(self.file, "w", encoding="utf-8") as f:

            json.dump(
                history,
                f,
                indent=4,
                ensure_ascii=False
            )

    def add(self, detection):

        history = self.load()

        key = detection["registry_key"]

        change = detection["change"]

        for item in history:

            if (
                item["registry_key"] == key and
                item["change"] == change
            ):

                item["count"] += 1

                item["last_seen"] = datetime.now().isoformat()

                self.save(history)

                return False

        detection["first_seen"] = datetime.now().isoformat()

        detection["last_seen"] = datetime.now().isoformat()

        detection["count"] = 1

        history.append(detection)

        self.save(history)

        return True