"""
agent/models.py

Data models used by the Registry Monitoring Agent.

Author: Your Name
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class RegistryRecord:
    """
    Represents a registry value captured from the system.
    """

    hive: str
    registry_path: str
    value_name: str
    value: Any
    value_type: int
    hash: str
    category: str
    severity: str
    description: str
    captured_at: str


@dataclass
class IntegrityChange:
    """
    Represents a detected integrity change.
    """

    change_type: str

    hive: str

    registry_path: str

    value_name: str

    severity: str

    category: str

    old_value: Any

    new_value: Any

    timestamp: str