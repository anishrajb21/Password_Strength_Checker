"""
agent/integrity.py

Registry Integrity Verification Engine

Author: Your Name
"""

from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime
import winreg

from config import MONITORED_KEYS, settings
from core.hashing import HashEngine
from core.logger import logger
from core.registry_reader import RegistryReader


class IntegrityChecker:
    """
    Compares the current registry state against the trusted baseline.
    """

    def __init__(self):

        self.baseline_file = Path(settings.paths["baseline"])
        self.report_file = Path(settings.paths["integrity_report"])

        # Ensure report directory exists
        self.report_file.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def hive_name(hive: int) -> str:
        """
        Convert registry hive constant to readable name.
        """

        mapping = {
            winreg.HKEY_CURRENT_USER: "HKEY_CURRENT_USER",
            winreg.HKEY_LOCAL_MACHINE: "HKEY_LOCAL_MACHINE",
            winreg.HKEY_CLASSES_ROOT: "HKEY_CLASSES_ROOT",
            winreg.HKEY_USERS: "HKEY_USERS",
            winreg.HKEY_CURRENT_CONFIG: "HKEY_CURRENT_CONFIG",
        }

        return mapping.get(hive, str(hive))

    def load_baseline(self):
        """
        Load baseline JSON.
        """

        if not self.baseline_file.exists():
            raise FileNotFoundError(
                f"Baseline file not found: {self.baseline_file}"
            )

        with open(
            self.baseline_file,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    def create_current_snapshot(self):
        """
        Read all monitored registry keys.
        """

        snapshot = {}

        for target in MONITORED_KEYS:

            values = RegistryReader.read_key(
                target.hive,
                target.path
            )

            hive = self.hive_name(target.hive)

            for value_name, value_info in values.items():

                unique_key = (
                    f"{hive}\\{target.path}::{value_name}"
                )

                snapshot[unique_key] = {

                    "value": value_info["value"],

                    "hash": HashEngine.sha256(
                        value_info["value"]
                    ),

                    "category": target.category,

                    "severity": target.severity,

                    "registry_path": target.path,

                    "value_name": value_name
                }

        return snapshot

    def compare(self):
        """
        Compare baseline with current registry.
        """

        logger.info("Loading baseline...")

        baseline = self.load_baseline()

        logger.info("Reading current registry...")

        current = self.create_current_snapshot()

        changes = []

        baseline_keys = set(baseline.keys())
        current_keys = set(current.keys())

        added = 0
        modified = 0
        deleted = 0

        # --------------------------
        # Added Values
        # --------------------------

        for key in current_keys - baseline_keys:

            added += 1

            changes.append({

                "change": "ADDED",

                "registry_key": key,

                "old_value": None,

                "new_value": current[key]["value"],

                "severity": current[key]["severity"],

                "category": current[key]["category"],

                "timestamp": datetime.now().isoformat()

            })

        # --------------------------
        # Deleted Values
        # --------------------------

        for key in baseline_keys - current_keys:

            deleted += 1

            changes.append({

                "change": "DELETED",

                "registry_key": key,

                "old_value": baseline[key]["value"],

                "new_value": None,

                "severity": baseline[key]["severity"],

                "category": baseline[key]["category"],

                "timestamp": datetime.now().isoformat()

            })

        # --------------------------
        # Modified Values
        # --------------------------

        for key in baseline_keys & current_keys:

            if baseline[key]["hash"] != current[key]["hash"]:

                modified += 1

                changes.append({

                    "change": "MODIFIED",

                    "registry_key": key,

                    "old_value": baseline[key]["value"],

                    "new_value": current[key]["value"],

                    "severity": current[key]["severity"],

                    "category": current[key]["category"],

                    "timestamp": datetime.now().isoformat()

                })

        unchanged = len(current_keys) - modified

        report = {

            "scan_information": {

                "scan_time": datetime.now().isoformat(),

                "baseline_file": str(self.baseline_file),

                "total_registry_values": len(current_keys)

            },

            "statistics": {

                "added": added,

                "modified": modified,

                "deleted": deleted,

                "unchanged": unchanged

            },

            "changes": changes

        }

        with open(

            self.report_file,

            "w",

            encoding="utf-8"

        ) as file:

            json.dump(

                report,

                file,

                indent=4,

                ensure_ascii=False

            )

        logger.info(
            f"Integrity report saved to {self.report_file}"
        )

        logger.info(
            f"Added={added}, Modified={modified}, Deleted={deleted}, Unchanged={unchanged}"
        )

        return report