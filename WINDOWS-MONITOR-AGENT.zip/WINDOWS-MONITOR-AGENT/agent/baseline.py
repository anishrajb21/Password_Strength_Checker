"""
agent/baseline.py

Creates the trusted registry baseline.

Author: Your Name
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
import winreg

from config import MONITORED_KEYS, settings
from core.hashing import HashEngine
from core.logger import logger
from core.registry_reader import RegistryReader


class BaselineGenerator:
    """
    Creates and stores the baseline registry snapshot.
    """

    def __init__(self):

        self.output_file = Path(
            settings.paths["baseline"]
        )

        self.output_file.parent.mkdir(
            parents=True,
            exist_ok=True
        )

    @staticmethod
    def hive_name(hive: int) -> str:

        mapping = {
            winreg.HKEY_CURRENT_USER: "HKEY_CURRENT_USER",
            winreg.HKEY_LOCAL_MACHINE: "HKEY_LOCAL_MACHINE",
            winreg.HKEY_CLASSES_ROOT: "HKEY_CLASSES_ROOT",
            winreg.HKEY_USERS: "HKEY_USERS",
            winreg.HKEY_CURRENT_CONFIG: "HKEY_CURRENT_CONFIG",
        }

        return mapping.get(hive, str(hive))

    def generate(self):

        baseline = {}

        logger.info("Generating registry baseline...")

        for target in MONITORED_KEYS:

            values = RegistryReader.read_key(
                target.hive,
                target.path
            )

            hive = self.hive_name(target.hive)

            for value_name, value_info in values.items():

                unique_key = (
                    f"{hive}\\{target.path}::{value_name}"
                )

                registry_value = value_info["value"]

                baseline[unique_key] = {

                    "hive": hive,

                    "category": target.category,

                    "severity": target.severity,

                    "description": target.description,

                    "registry_path": target.path,

                    "value_name": value_name,

                    "value": registry_value,

                    "value_type": value_info["type"],

                    "hash": HashEngine.sha256(
                        registry_value
                    ),

                    "captured_at": datetime.now().isoformat()

                }

        with open(
            self.output_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                baseline,
                file,
                indent=4,
                ensure_ascii=False
            )

        logger.info(
            f"Baseline saved to {self.output_file}"
        )

        logger.info(
            f"Total Registry Values Captured: {len(baseline)}"
        )


if __name__ == "__main__":

    BaselineGenerator().generate()