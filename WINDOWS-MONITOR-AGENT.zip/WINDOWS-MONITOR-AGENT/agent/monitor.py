"""
agent.monitor

Continuous Windows Registry Monitoring Engine
"""

from __future__ import annotations

import time
from datetime import datetime

from config import settings
from core.logger import logger
from agent.integrity import IntegrityChecker
from agent.report_utils import ReportPrinter


class RegistryMonitor:
    """
    Continuously monitors registry integrity.
    """

    def __init__(self):

        self.interval = settings.monitoring["interval_seconds"]

        self.checker = IntegrityChecker()

        self.running = False

    def monitor_once(self):

        logger.info("Starting registry integrity scan...")

        report = self.checker.compare()

        stats = report["statistics"]

        total_changes = len(report["changes"])

        if total_changes == 0:

            logger.info("No registry changes detected.")

        else:

            logger.warning(
                f"{total_changes} registry change(s) detected."
            )

            ReportPrinter.print_changes(report)

        return report

    def start(self):

        self.running = True

        logger.info(
            f"Registry Monitor Started (Interval: {self.interval}s)"
        )

        try:

            while self.running:

                start = datetime.now()

                self.monitor_once()

                end = datetime.now()

                elapsed = (end - start).total_seconds()

                logger.info(
                    f"Scan completed in {elapsed:.2f} sec"
                )

                time.sleep(self.interval)

        except KeyboardInterrupt:

            logger.info(
                "Registry Monitor stopped by user."
            )

            print("\nMonitoring stopped.")

    def stop(self):

        self.running = False
