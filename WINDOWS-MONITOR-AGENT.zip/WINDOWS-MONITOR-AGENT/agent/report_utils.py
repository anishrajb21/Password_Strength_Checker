"""
agent/report_utils.py

Utilities for displaying registry integrity reports.

Author: Your Name
"""

from __future__ import annotations


class ReportPrinter:

    @staticmethod
    def print_summary(report):

        stats = report["statistics"]

        print("\n" + "=" * 70)
        print("WINDOWS REGISTRY INTEGRITY REPORT")
        print("=" * 70)

        print(f"Scan Time             : {report['scan_information']['scan_time']}")
        print(f"Baseline File         : {report['scan_information']['baseline_file']}")
        print(f"Registry Values       : {report['scan_information']['total_registry_values']}")

        print()

        print(f"Added                 : {stats['added']}")
        print(f"Modified              : {stats['modified']}")
        print(f"Deleted               : {stats['deleted']}")
        print(f"Unchanged             : {stats['unchanged']}")

        print()

        print(f"Total Changes         : {len(report['changes'])}")

        print("=" * 70)

    @staticmethod
    def print_changes(report):

        changes = report["changes"]

        if not changes:

            print("No Registry Integrity Violations Detected.")

            return

        print()

        print("Detected Registry Changes")

        print("-" * 70)

        for index, item in enumerate(changes, start=1):

            print(f"[{index}] {item['change']}")
            print(f"Registry Key : {item['registry_key']}")
            print(f"Category     : {item['category']}")
            print(f"Severity     : {item['severity']}")
            print(f"Timestamp    : {item['timestamp']}")

            if item["old_value"] is not None:
                print(f"Old Value    : {item['old_value']}")

            if item["new_value"] is not None:
                print(f"New Value    : {item['new_value']}")

            print("-" * 70)