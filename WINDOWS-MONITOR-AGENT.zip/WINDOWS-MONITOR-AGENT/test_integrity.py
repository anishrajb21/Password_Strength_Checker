from agent.integrity import IntegrityChecker
from agent.report_utils import ReportPrinter

checker = IntegrityChecker()

report = checker.compare()

ReportPrinter.print_summary(report)

ReportPrinter.print_changes(report)