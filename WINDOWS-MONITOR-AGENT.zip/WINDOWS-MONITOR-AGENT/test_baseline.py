from agent.baseline import BaselineGenerator

BaselineGenerator().generate()