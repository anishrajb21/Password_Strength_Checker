"""
config/registry_keys.py

Defines every registry location monitored by the Registry
Change Monitoring Agent.

Author: Your Name
"""

from dataclasses import dataclass
from typing import List
import winreg


@dataclass(frozen=True)
class RegistryTarget:
    """
    Represents a monitored registry location.
    """

    hive: int
    path: str
    category: str
    severity: str
    description: str


# ==========================================================
# Persistence (Autorun)
# ==========================================================

AUTORUN_KEYS: List[RegistryTarget] = [

    RegistryTarget(
        hive=winreg.HKEY_CURRENT_USER,
        path=r"Software\Microsoft\Windows\CurrentVersion\Run",
        category="Persistence",
        severity="HIGH",
        description="Current User Startup Programs"
    ),

    RegistryTarget(
        hive=winreg.HKEY_CURRENT_USER,
        path=r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
        category="Persistence",
        severity="HIGH",
        description="Current User RunOnce Programs"
    ),

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"Software\Microsoft\Windows\CurrentVersion\Run",
        category="Persistence",
        severity="CRITICAL",
        description="Machine Startup Programs"
    ),

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
        category="Persistence",
        severity="CRITICAL",
        description="Machine RunOnce Programs"
    )

]


# ==========================================================
# Windows Defender
# ==========================================================

DEFENDER_KEYS: List[RegistryTarget] = [

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"SOFTWARE\Policies\Microsoft\Windows Defender",
        category="Security",
        severity="CRITICAL",
        description="Windows Defender Policies"
    )

]


# ==========================================================
# User Account Control
# ==========================================================

UAC_KEYS: List[RegistryTarget] = [

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
        category="Security",
        severity="CRITICAL",
        description="User Account Control"
    )

]


# ==========================================================
# Winlogon
# ==========================================================

WINLOGON_KEYS: List[RegistryTarget] = [

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon",
        category="System",
        severity="CRITICAL",
        description="Windows Logon Configuration"
    )

]


# ==========================================================
# Firewall
# ==========================================================

FIREWALL_KEYS: List[RegistryTarget] = [

    RegistryTarget(
        hive=winreg.HKEY_LOCAL_MACHINE,
        path=r"SYSTEM\CurrentControlSet\Services\SharedAccess",
        category="Firewall",
        severity="HIGH",
        description="Windows Firewall"
    )

]


# ==========================================================
# Final List
# ==========================================================

MONITORED_KEYS: List[RegistryTarget] = (
    AUTORUN_KEYS +
    DEFENDER_KEYS +
    UAC_KEYS +
    WINLOGON_KEYS +
    FIREWALL_KEYS
)