"""
config/detection_rules.py

Enterprise Registry Malware Detection Rules
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class DetectionRule:

    category: str
    registry_path: str
    description: str
    severity: str
    score: int
    confidence: str
    mitre: str
    recommendation: str


RULES = [

    DetectionRule(
        category="Persistence",
        registry_path=r"Software\Microsoft\Windows\CurrentVersion\Run",
        description="Autorun registry entry modified.",
        severity="HIGH",
        score=85,
        confidence="HIGH",
        mitre="T1547.001",
        recommendation="Verify executable path and digital signature."
    ),

    DetectionRule(
        category="Persistence",
        registry_path=r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
        description="RunOnce registry entry modified.",
        severity="HIGH",
        score=80,
        confidence="HIGH",
        mitre="T1547.001",
        recommendation="Verify startup program legitimacy."
    ),

    DetectionRule(
        category="Windows Defender",
        registry_path=r"Software\Policies\Microsoft\Windows Defender",
        description="Windows Defender configuration changed.",
        severity="CRITICAL",
        score=100,
        confidence="VERY HIGH",
        mitre="T1562.001",
        recommendation="Immediately investigate potential security tampering."
    ),

    DetectionRule(
        category="Firewall",
        registry_path=r"SYSTEM\CurrentControlSet\Services\SharedAccess",
        description="Firewall configuration modified.",
        severity="HIGH",
        score=90,
        confidence="HIGH",
        mitre="T1562",
        recommendation="Review firewall settings."
    ),

    DetectionRule(
        category="Winlogon",
        registry_path=r"Software\Microsoft\Windows NT\CurrentVersion\Winlogon",
        description="Winlogon configuration changed.",
        severity="CRITICAL",
        score=100,
        confidence="VERY HIGH",
        mitre="T1547",
        recommendation="Verify Shell and Userinit values immediately."
    ),

    DetectionRule(
        category="UAC",
        registry_path=r"Software\Microsoft\Windows\CurrentVersion\Policies\System",
        description="User Account Control configuration changed.",
        severity="HIGH",
        score=90,
        confidence="HIGH",
        mitre="T1548",
        recommendation="Review privilege escalation settings."
    ),

]