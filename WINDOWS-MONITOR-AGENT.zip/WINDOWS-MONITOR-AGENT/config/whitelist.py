"""
config/whitelist.py

Registry whitelist.
Entries matching these patterns will not generate malware alerts.
"""

WHITELIST = [

    "OneDrive",

    "Windows Security",

    "MicrosoftEdgeAutoLaunch",

    "SecurityHealth",

    "Windows Defender",

    "WindowsTerminal"

]