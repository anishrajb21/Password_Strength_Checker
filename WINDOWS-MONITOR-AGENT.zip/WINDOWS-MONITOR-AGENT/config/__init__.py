from .settings import settings
from .registry_keys import MONITORED_KEYS, RegistryTarget