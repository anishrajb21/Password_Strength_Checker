"""
config/settings.py

Loads application configuration from config.json.
Every module imports settings from here.
"""

from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "config" / "config.json"


class Settings:

    def __init__(self):

        with open(CONFIG_FILE, "r", encoding="utf-8") as file:
            self.config = json.load(file)

    @property
    def monitoring(self):
        return self.config["monitoring"]

    @property
    def monitor_interval(self):
        return self.config["monitoring"]["interval_seconds"]

    @property
    def paths(self):
        return self.config["paths"]

    @property
    def hashing(self):
        return self.config["hashing"]

    @property
    def alerts(self):
        return self.config["alerts"]

    @property
    def project(self):
        return self.config["project"]


settings = Settings()