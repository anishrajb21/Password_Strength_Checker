from config import MONITORED_KEYS

print("=" * 80)

for target in MONITORED_KEYS:

    print(f"Category    : {target.category}")
    print(f"Severity    : {target.severity}")
    print(f"Description : {target.description}")
    print(f"Path        : {target.path}")
    print("-" * 80)