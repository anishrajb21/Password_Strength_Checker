from agent.integrity import IntegrityChecker
from agent.malware_detector import MalwareDetector

checker = IntegrityChecker()

report = checker.compare()

detector = MalwareDetector()

result = detector.analyze(report)

detections = result["detections"]

statistics = result["statistics"]

print("\n" + "=" * 80)
print("WINDOWS REGISTRY MALWARE DETECTION REPORT")
print("=" * 80)

print("\nDetection Statistics")

print("-" * 80)

print(f"Total Detections : {statistics['total_detections']}")
print(f"Average Risk     : {statistics['average_risk_score']}")

print()

print("Severity Distribution")

for severity, count in statistics["severity"].items():

    print(f"{severity:<12} : {count}")

print()

print("Categories")

for category, count in statistics["categories"].items():

    print(f"{category:<20} : {count}")

print()

if not detections:

    print("No suspicious registry activity detected.")

else:

    print()

    print("=" * 80)

    for index, item in enumerate(detections, start=1):

        print(f"Detection #{index}")

        print("-" * 80)

        print(f"Category        : {item['category']}")

        print(f"Severity        : {item['severity']}")

        print(f"Risk Score      : {item['risk_score']}")

        print(f"Confidence      : {item['confidence']}")

        print(f"MITRE ATT&CK    : {item['mitre']}")

        print(f"Registry Key    : {item['registry_key']}")

        print(f"Description     : {item['description']}")

        print(f"Recommendation  : {item['recommendation']}")

        print(f"Timestamp       : {item['timestamp']}")

        print()

print("=" * 80)