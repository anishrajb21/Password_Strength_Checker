from core.hashing import HashEngine

text = "Hello Registry"

print(HashEngine.sha256(text))