from config import settings


print("=" * 50)

print(settings.project)

print()

print(settings.monitoring)

print()

print(settings.paths)

print()

print(settings.hashing)

print("=" * 50)