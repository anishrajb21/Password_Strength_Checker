"""
core/registry_reader.py

Provides a reusable interface for reading Windows Registry keys.

Author: Your Name
"""

from __future__ import annotations

import winreg
from typing import Dict, Any, List

from core.logger import logger


class RegistryReader:
    """
    Reads Windows Registry keys and returns JSON-serializable
    Python dictionaries.

    This class abstracts all direct interactions with the
    Windows Registry.
    """

    @staticmethod
    def normalize_value(value: Any) -> Any:
        """
        Convert registry values into JSON-serializable objects.

        Parameters
        ----------
        value : Any
            Registry value.

        Returns
        -------
        Any
            JSON-safe value.
        """

        if isinstance(value, bytes):
            return value.hex()

        if isinstance(value, tuple):
            return list(value)

        if isinstance(value, list):
            return value

        if value is None:
            return None

        return value

    @staticmethod
    def read_key(hive: int, path: str) -> Dict[str, Any]:
        """
        Read every value inside a registry key.

        Parameters
        ----------
        hive : int
            Registry hive.

        path : str
            Registry path.

        Returns
        -------
        dict
            Dictionary containing registry values.
        """

        values: Dict[str, Any] = {}

        try:

            registry_key = winreg.OpenKey(
                hive,
                path,
                0,
                winreg.KEY_READ
            )

            index = 0

            while True:

                try:

                    name, value, value_type = winreg.EnumValue(
                        registry_key,
                        index
                    )

                    values[name] = {
                        "value": RegistryReader.normalize_value(value),
                        "type": value_type
                    }

                    index += 1

                except OSError:
                    break

            winreg.CloseKey(registry_key)

        except FileNotFoundError:

            logger.warning(
                f"Registry key not found: {path}"
            )

        except PermissionError:

            logger.error(
                f"Permission denied: {path}"
            )

        except Exception as error:

            logger.exception(error)

        return values

    @staticmethod
    def key_exists(hive: int, path: str) -> bool:
        """
        Check whether a registry key exists.
        """

        try:

            key = winreg.OpenKey(hive, path)

            winreg.CloseKey(key)

            return True

        except Exception:

            return False

    @staticmethod
    def list_value_names(hive: int, path: str) -> List[str]:
        """
        Return all value names inside a registry key.
        """

        values = RegistryReader.read_key(
            hive,
            path
        )

        return list(values.keys())