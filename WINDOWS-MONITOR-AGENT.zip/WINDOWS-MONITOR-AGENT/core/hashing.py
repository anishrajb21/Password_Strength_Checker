"""
core/hashing.py

Provides cryptographic hashing utilities used throughout the
Registry Monitoring Agent.

Author: Your Name
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


class HashEngine:
    """
    Utility class for generating SHA-256 hashes.
    """

    @staticmethod
    def sha256(data: Any) -> str:
        """
        Generate a SHA-256 hash for any JSON-serializable object.

        Parameters
        ----------
        data : Any
            Data to hash.

        Returns
        -------
        str
            SHA-256 hexadecimal digest.
        """

        try:

            serialized = json.dumps(
                data,
                sort_keys=True,
                ensure_ascii=False,
                default=str
            )

        except Exception:

            serialized = str(data)

        return hashlib.sha256(
            serialized.encode("utf-8")
        ).hexdigest()