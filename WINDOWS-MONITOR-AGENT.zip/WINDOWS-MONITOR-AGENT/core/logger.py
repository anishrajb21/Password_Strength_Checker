"""
core/logger.py

Central logging system for the Registry Monitoring Agent.
"""

import logging
import sys
from pathlib import Path

from config import settings


class LoggerManager:
    """
    Creates a singleton logger for the application.
    """

    _logger = None

    @classmethod
    def get_logger(cls):

        if cls._logger:
            return cls._logger

        logger = logging.getLogger("RegistryMonitor")

        logger.setLevel(logging.DEBUG)

        logger.propagate = False

        formatter = logging.Formatter(

            fmt="%(asctime)s | %(levelname)-8s | %(message)s",

            datefmt="%Y-%m-%d %H:%M:%S"

        )

        # Console Handler
        console_handler = logging.StreamHandler(sys.stdout)

        console_handler.setFormatter(formatter)

        console_handler.setLevel(logging.INFO)

        logger.addHandler(console_handler)

        # File Handler
        log_file = Path(settings.paths["log_file"])

        log_file.parent.mkdir(parents=True, exist_ok=True)

        file_handler = logging.FileHandler(
            log_file,
            encoding="utf-8"
        )

        file_handler.setFormatter(formatter)

        file_handler.setLevel(logging.DEBUG)

        logger.addHandler(file_handler)

        cls._logger = logger

        return logger


logger = LoggerManager.get_logger()