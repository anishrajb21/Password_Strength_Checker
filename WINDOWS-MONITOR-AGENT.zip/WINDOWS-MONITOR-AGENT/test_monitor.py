from agent.monitor import RegistryMonitor

monitor = RegistryMonitor()

monitor.start()