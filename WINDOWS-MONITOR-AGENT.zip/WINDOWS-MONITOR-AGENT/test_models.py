from agent.models import RegistryRecord

record = RegistryRecord(
    hive="HKCU",
    registry_path=r"Software\Test",
    value_name="Example",
    value="Hello",
    value_type=1,
    hash="12345",
    category="Persistence",
    severity="HIGH",
    description="Testing",
    captured_at="2026"
)

print(record)