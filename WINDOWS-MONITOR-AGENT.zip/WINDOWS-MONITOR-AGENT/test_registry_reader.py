import winreg

from core.registry_reader import RegistryReader


path = r"Software\Microsoft\Windows\CurrentVersion\Run"

result = RegistryReader.read_key(
    winreg.HKEY_CURRENT_USER,
    path
)

print("=" * 60)

print(result)

print("=" * 60)