from core.logger import logger


logger.info("Registry Monitor Started")

logger.warning("Unknown startup entry detected.")

logger.error("Registry key cannot be accessed.")

logger.critical("Windows Defender has been disabled.")